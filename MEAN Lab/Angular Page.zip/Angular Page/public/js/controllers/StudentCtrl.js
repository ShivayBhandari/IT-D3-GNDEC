angular.module('StudentCtrl', []).controller('StudentController', function ($scope) {
    $scope.tagline = 'Welcome to Student section!';
});