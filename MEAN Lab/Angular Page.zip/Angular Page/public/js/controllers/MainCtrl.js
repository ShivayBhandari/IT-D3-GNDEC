angular.module('MainCtrl', []).controller('MainController', function ($scope) {
    $scope.tagline = 'Welcome to tutorials point angular app!';
});